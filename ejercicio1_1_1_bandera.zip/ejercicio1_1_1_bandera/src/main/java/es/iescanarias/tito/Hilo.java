package es.iescanarias.tito;

import java.util.function.Consumer;

import javafx.application.Platform;

public class Hilo {
    
    public void bandera(double y, double inicioY, Consumer<Double> actualizarY){
        Thread hilo = new Thread (() -> {
            double posicionInicio = inicioY;
            System.out.println("Origen" + posicionInicio + "Destino" + y);
            try {
                while (posicionInicio > y) {
                    Thread.sleep(20);
                    posicionInicio -=1;

                    if(posicionInicio % 50 == 0){
                        System.out.println("Moviendo---- Posicion actual: "+ inicioY);

                    }
                    double posicionFinal = posicionInicio;
                    Platform.runLater(()-> { 
                        actualizarY.accept(posicionFinal);
                    });
                }
                System.out.println("----Bandera llega a la cima-----");
            } catch (Exception e) {
                e.printStackTrace();
            }

        });
        hilo.setDaemon(true);
        hilo.start();
    }

}
