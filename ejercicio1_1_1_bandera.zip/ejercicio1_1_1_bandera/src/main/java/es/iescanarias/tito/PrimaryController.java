package es.iescanarias.tito;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;

public class PrimaryController {

    @FXML
    private ImageView asta;

    @FXML
    private ImageView bandera;

    @FXML
    public void initialize() {
        System.out.println("1. Controlador iniciado.");

        Hilo hilo = new Hilo();

      

        hilo.bandera(65, 350, nuevaPosicionY -> {
            bandera.setLayoutY(nuevaPosicionY);
        });
    }
}
