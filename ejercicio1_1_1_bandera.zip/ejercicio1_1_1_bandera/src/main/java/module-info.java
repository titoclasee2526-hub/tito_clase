module es.iescanarias.tito {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;

    opens es.iescanarias.tito to javafx.fxml;
    exports es.iescanarias.tito;
}
